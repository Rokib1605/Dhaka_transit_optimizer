#include <bits/stdc++.h>
using namespace std;

static inline string newline() { return "\n"; }
static inline double INF_D() { return numeric_limits<double>::infinity(); }

struct Vertex {
    pair<double,double> lonlat;               
    vector<pair<int,double>> adj;             
    double cost = INF_D();                    
    int prev = -1;                            
    double arrival = INF_D();                 
    double waiting = 0.0;                     

    Vertex() = default;
    Vertex(pair<double,double> p): lonlat(p) {}
};

static inline double deg2rad(double deg) { return deg * (acos(-1.0) / 180.0); }

double haversine_km(const pair<double,double>& a, const pair<double,double>& b) {
    const double R = 6371.0;
    double lon1 = deg2rad(a.first), lat1 = deg2rad(a.second);
    double lon2 = deg2rad(b.first), lat2 = deg2rad(b.second);
    double dlat = lat2 - lat1;
    double dlon = lon2 - lon1;
    double s = sin(dlat/2.0);
    double t = sin(dlon/2.0);
    double A = s*s + cos(lat1) * cos(lat2) * t*t;
    double C = 2.0 * atan2(sqrt(A), sqrt(1.0 - A));
    return R * C;
}

double parseTimeToMinutes(const string &ts) {
    string s = ts;
    while (!s.empty() && isspace((unsigned char)s.back())) s.pop_back();
    while (!s.empty() && isspace((unsigned char)s.front())) s.erase(s.begin());
    if (s.empty()) return 0.0;

    string tail;
    if (s.size() >= 2) {
        tail = s.substr(s.size()-2);
        for (char &c: tail) c = tolower(c);
    } else tail = "";

    int hours = 0, minutes = 0;
    string core = s;
    if (tail == "am" || tail == "pm") core = s.substr(0, s.size()-2);
    core.erase(remove_if(core.begin(), core.end(), ::isspace), core.end());

    if (sscanf(core.c_str(), "%d:%d", &hours, &minutes) != 2) return 0.0;

    if (tail == "pm" && hours < 12) hours += 12;
    if (tail == "am" && hours == 12) hours = 0;

    return double(hours * 60 + minutes);
}

string minutesToTimeStr(double minutes_d) {
    int minutes = static_cast<int>(floor(minutes_d + 0.5)); 
    minutes %= 1440;
    if (minutes < 0) minutes += 1440;
    int hours = minutes / 60;
    int mins = minutes % 60;
    string period = (hours >= 12) ? "pm" : "am";
    int displayHour = hours % 12;
    if (displayHour == 0) displayHour = 12;
    char buf[16];
    snprintf(buf, sizeof(buf), "%02d:%02d%s", displayHour, mins, period.c_str());
    return string(buf);
}

string trim(const string &s) {
    const string WHITESPACE = " \n\r\t\f\v";
    size_t start = s.find_first_not_of(WHITESPACE);
    if (start == string::npos) return "";
    size_t end = s.find_last_not_of(WHITESPACE);
    return s.substr(start, end - start + 1);
}

vector<pair<double,double>> parse_lonlat_pairs(const string &line) {
    vector<pair<double,double>> out;
    if (line.empty()) return out;
    stringstream ss(line);
    string token;
    if (!getline(ss, token, ',')) return out;
    vector<string> toks;
    while (getline(ss, token, ',')) toks.push_back(trim(token));
    for (size_t i = 0; i + 1 < toks.size(); i += 2) {
        if (toks[i].empty() || toks[i+1].empty()) continue;
        try {
            double lon = stod(toks[i]);
            double lat = stod(toks[i+1]);
            out.emplace_back(lon, lat);
        } catch (...) {
            continue;
        }
    }
    return out;
}

int find_or_create_vertex(map<pair<double,double>,int> &coordToId, vector<Vertex> &nodes, const pair<double,double> &coord) {
    auto it = coordToId.find(coord);
    if (it != coordToId.end()) return it->second;
    int id = (int)nodes.size();
    nodes.emplace_back(Vertex(coord));
    coordToId[coord] = id;
    return id;
}

void build_graph_from_csv(const string &filename,
                          vector<Vertex> &nodes,
                          map<pair<double,double>,int> &coordToId,
                          map<pair<int,int>,int> &edgeMode,
                          int mode)
{
    ifstream fin(filename);
    if (!fin.is_open()) {
        cerr << "Cant open the dataset of map - " << filename << newline();
        return;
    }

    int costPerKm = 7;
    if (mode == 2) costPerKm = 20;
    else if (mode == 3) costPerKm = 5;
    else costPerKm = 7;

    string line;
    while (getline(fin, line)) {
        auto pts = parse_lonlat_pairs(line);
        if (pts.size() < 2) continue;
        for (size_t i = 0; i + 1 < pts.size(); ++i) {
            int u = find_or_create_vertex(coordToId, nodes, pts[i]);
            int v = find_or_create_vertex(coordToId, nodes, pts[i+1]);
            double dkm = haversine_km(pts[i], pts[i+1]);
            double cost = dkm * costPerKm;
            nodes[u].adj.emplace_back(v, cost);
            nodes[v].adj.emplace_back(u, cost);
            edgeMode[{u,v}] = mode;
            edgeMode[{v,u}] = mode;
        }
    }
    fin.close();
}

void dijkstra_timeaware(int src, vector<Vertex> &nodes, map<pair<int,int>,int> &edgeMode, double startTimeMinutes) {
    for (int i = 1; i < (int)nodes.size(); ++i) {
        nodes[i].cost = INF_D();
        nodes[i].arrival = INF_D();
        nodes[i].prev = -1;
        nodes[i].waiting = 0.0;
    }

    nodes[src].cost = 0.0;
    nodes[src].arrival = startTimeMinutes;
    nodes[src].waiting = 0.0;

    set<pair<double,int>> pq;
    for (int i = 1; i < (int)nodes.size(); ++i) pq.insert({nodes[i].cost, i});

    while (!pq.empty()) {
        auto it = pq.begin();
        int v = it->second;
        pq.erase(it);

        if (nodes[v].cost == INF_D()) break;

        int prevMode = 0;
        if (nodes[v].prev != -1) {
            auto f = edgeMode.find({nodes[v].prev, v});
            if (f != edgeMode.end()) prevMode = f->second;
        }

        double possible_wait = 0.0;
        double at = nodes[v].arrival;
        if (isfinite(at)) {
            int at_int = static_cast<int>(floor(at));
            double frac = at - at_int;
            if ((at_int % 15) != 0 || frac > 0.0) {
                int wait_until = at_int - (at_int % 15) + 15;
                possible_wait = double(wait_until) - at;
                if (possible_wait < 0) possible_wait = 0.0;
            }
        }

        for (auto &edge : nodes[v].adj) {
            int u = edge.first;
            double edgeCost = edge.second; 
            int mode = 1;
            auto mIt = edgeMode.find({v, u});
            if (mIt != edgeMode.end()) mode = mIt->second;

            double speed_kmh = (mode == 1) ? 2.0 : 30.0;
            double dist_km = haversine_km(nodes[v].lonlat, nodes[u].lonlat);
            double travel_minutes = (dist_km / speed_kmh) * 60.0;

            double waiting = 0.0;
            if ((mode == 3 || mode == 4 || mode == 5) && (mode != prevMode)) {
                waiting = possible_wait;
            }

            bool service_ok = true;
            if ((mode > 2) && (mode != prevMode)) {
                double departure = nodes[v].arrival + waiting;
                if (!(departure >= 360.0 && departure <= 1380.0)) service_ok = false;
            }

            if (!service_ok) continue;
            if (nodes[v].cost == INF_D()) continue;

            double candCost = nodes[v].cost + edgeCost;
            if (candCost + 1e-9 < nodes[u].cost) {
                auto found = pq.find({nodes[u].cost, u});
                if (found != pq.end()) pq.erase(found);
                nodes[u].cost = candCost;
                nodes[u].prev = v;
                nodes[u].waiting = waiting;
                nodes[u].arrival = nodes[v].arrival + waiting + travel_minutes;
                pq.insert({nodes[u].cost, u});
            }
        }
    }
}

string mode_name(int mode) {
    if (mode == 1) return "Walk";
    if (mode == 2) return "Car";
    if (mode == 3) return "Metro";
    if (mode == 4) return "Uttara Bus";
    if (mode == 5) return "Bikolpo Bus";
    return "Unknown";
}

void write_kml(const string &filename, const vector<int> &path, const vector<Vertex> &nodes) {
    ofstream kml(filename);
    if (!kml.is_open()) { cerr << "Could not write KML file" << newline(); return; }
    kml << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    kml << "<kml xmlns=\"http://www.opengis.net/kml/2.2\">\n";
    kml << "<Document>\n";
    kml << "<name>Cheapest Path with time</name>\n";
    kml << "<Placemark>\n";
    kml << "<name>Route</name>\n";
    kml << "<Style>\n";
    kml << "<LineStyle>\n";
    kml << "<color>ff0000ff</color>\n";
    kml << "<width>4</width>\n";
    kml << "</LineStyle>\n";
    kml << "</Style>\n";
    kml << "<LineString>\n";
    kml << "<tessellate>1</tessellate>\n";
    kml << "<coordinates>\n";
    for (int id : path) {
        double lon = nodes[id].lonlat.first;
        double lat = nodes[id].lonlat.second;
        kml << lon << "," << lat << ",0\n";
    }
    kml << "</coordinates>\n";
    kml << "</LineString>\n";
    kml << "</Placemark>\n";
    kml << "</Document>\n";
    kml << "</kml>\n";
    kml.close();
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    vector<Vertex> nodes;
    nodes.emplace_back();

    map<pair<double,double>,int> coordToId;
    map<pair<int,int>,int> edgeMode;

    build_graph_from_csv("Roadmap-Dhaka.csv", nodes, coordToId, edgeMode, 2);
    build_graph_from_csv("Routemap-DhakaMetroRail.csv", nodes, coordToId, edgeMode, 3);
    build_graph_from_csv("Routemap-UttaraBus.csv", nodes, coordToId, edgeMode, 4);     
    build_graph_from_csv("Routemap-BikolpoBus.csv", nodes, coordToId, edgeMode, 5);

    pair<double,double> src, dst;
    string startTimeStr;
    if (!(cin >> src.first >> src.second)) { cerr << "Bad input for source\n"; return 1; }
    if (!(cin >> dst.first >> dst.second)) { cerr << "Bad input for destination\n"; return 1; }
    if (!(cin >> startTimeStr)) { cerr << "Bad input for start time\n"; return 1; }

    cout << fixed << setprecision(6);
    cout << "Source Longitude = " << src.first << newline();
    cout << "Source Latitude = " << src.second << newline();
    cout << "Destination Longitude = " << dst.first << newline();
    cout << "Destination Latitude = " << dst.second << newline();
    cout << "Starting Time = " << startTimeStr << newline();

    double startMinutes = parseTimeToMinutes(startTimeStr);

    int srcId, dstId;
    auto itS = coordToId.find(src);
    if (itS == coordToId.end()) {
        int nearest = -1;
        double best = INF_D();
        for (int i = 1; i < (int)nodes.size(); ++i) {
            double d = haversine_km(src, nodes[i].lonlat);
            if (d < best) { best = d; nearest = i; }
        }
        if (nearest == -1) { cerr << "Empty graph, cannot connect source\n"; return 1; }
        srcId = (int)nodes.size();
        coordToId[src] = srcId;
        nodes.emplace_back(Vertex(src));
        nodes[srcId].adj.emplace_back(nearest, 0.0);
        nodes[nearest].adj.emplace_back(srcId, 0.0);
        edgeMode[{srcId, nearest}] = 1;
        edgeMode[{nearest, srcId}] = 1;
    } else srcId = itS->second;

    auto itD = coordToId.find(dst);
    if (itD == coordToId.end()) {
        int nearest = -1;
        double best = INF_D();
        for (int i = 1; i < (int)nodes.size(); ++i) {
            if (i == srcId) continue;
            double d = haversine_km(dst, nodes[i].lonlat);
            if (d < best) { best = d; nearest = i; }
        }
        if (nearest == -1) { cerr << "Empty graph, cannot connect destination\n"; return 1; }
        dstId = (int)nodes.size();
        coordToId[dst] = dstId;
        nodes.emplace_back(Vertex(dst));
        nodes[dstId].adj.emplace_back(nearest, 0.0);
        nodes[nearest].adj.emplace_back(dstId, 0.0);
        edgeMode[{dstId, nearest}] = 1;
        edgeMode[{nearest, dstId}] = 1;
    } else dstId = itD->second;

    dijkstra_timeaware(srcId, nodes, edgeMode, startMinutes);

    if (nodes[dstId].cost == INF_D()) {
        cout << "NO path" << newline();
        return 0;
    }

    cout << newline() << "Cheapest Cost = " << nodes[dstId].cost << " (Tk)" << newline() << newline();

    vector<int> path;
    int cur = dstId;
    while (cur != -1) {
        path.push_back(cur);
        cur = nodes[cur].prev;
    }
    reverse(path.begin(), path.end());

    for (size_t i = 0; i + 1 < path.size(); ++i) {
        int u = path[i], v = path[i+1];
        double dist_km = haversine_km(nodes[u].lonlat, nodes[v].lonlat);
        int mode = 1;
        auto mIt = edgeMode.find({u,v});
        if (mIt != edgeMode.end()) mode = mIt->second;

        double start_leg = nodes[u].arrival + nodes[v].waiting;
        double end_leg   = nodes[v].arrival;

        cout << "Segment " << (i+1) << ": From ("
             << nodes[u].lonlat.first << ", " << nodes[u].lonlat.second << ")"
             << " -> To (" << nodes[v].lonlat.first << ", " << nodes[v].lonlat.second << ")"
             << " | Mode: " << mode_name(mode)
             << " | Distance: " << fixed << setprecision(6) << dist_km << " km"
             << " | Time: " << minutesToTimeStr(start_leg) << " To " << minutesToTimeStr(end_leg)
             << newline();
    }

    // write KML
    write_kml("Problem-4.kml", path, nodes);
    cout << newline() << "KML written to Problem-4.kml" << newline();

    return 0;
}
